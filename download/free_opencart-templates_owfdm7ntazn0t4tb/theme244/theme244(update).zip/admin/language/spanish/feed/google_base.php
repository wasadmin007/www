<?php
// Heading
$_['heading_title']    = 'Google Base';

// Text   
$_['text_feed']        = 'Feed de productos';
$_['text_success']     = 'Correcto: Ha modificado Google Base feed!';

// Entry
$_['entry_status']     = 'Estado:';
$_['entry_data_feed']  = 'URL de feed de datos:';

// Error
$_['error_permission'] = 'Advertencia: No tiene permiso para modificar el feed de Google Base!';
?>