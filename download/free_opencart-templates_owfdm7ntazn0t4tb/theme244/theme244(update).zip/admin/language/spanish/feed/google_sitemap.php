<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text 
$_['text_feed']        = 'Feeds de Producto';
$_['text_success']     = 'Correcto: Ha modificado el feed de Google Sitemap!';

// Entry
$_['entry_status']     = 'Estado:';
$_['entry_data_feed']  = 'Url del feed:';

// Error
$_['error_permission'] = 'Advertencia: No tiene permiso para modificar el feed de Google Sitemap!';
?>