<?php
// header
$_['heading_title']  = 'Administración';

// Text
$_['text_heading']   = 'Administración';
$_['text_login']     = 'Detalles de su Conexión';
$_['text_forgotten'] = 'Clave Olvidada';

// Entry
$_['entry_username'] = 'Nombre Usuario:';
$_['entry_password'] = 'Clave:';

// Button
$_['button_login']   = 'Conectar';

// Error
$_['error_login']    = 'No coincide nombre de usuario y/o contraseña.';
$_['error_token']    = 'Sesión inválida. Por favor, intente de nuevo.';
?>
