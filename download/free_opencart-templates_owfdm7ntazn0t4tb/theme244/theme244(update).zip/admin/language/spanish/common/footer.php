<?php
// Text
$_['text_footer'] = '<a href="http://www.opencart.com">Opencart</a> &copy; ' . date('Y') . ' Todos los Derechos Reservados.';
?>