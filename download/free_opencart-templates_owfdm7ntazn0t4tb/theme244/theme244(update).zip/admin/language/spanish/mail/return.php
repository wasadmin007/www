<?php
// Text
$_['text_subject']       = '%s - Devolución Actualizada %s';
$_['text_return_id']     = 'ID Devolución:';
$_['text_date_added']    = 'Fecha de Devolución:';
$_['text_return_status'] = 'Su Devolución ha sido Actualizada al siguiente estado:';
$_['text_comment']       = 'Los comentarios para su Devolución son:';
$_['text_footer']        = 'Por Favor responda este E-Mail sí tiene preguntas.';
?>