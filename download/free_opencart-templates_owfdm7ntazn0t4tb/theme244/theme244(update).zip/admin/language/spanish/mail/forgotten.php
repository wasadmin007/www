<?php
// Text
$_['text_subject']  = '%s - ha solicitado Resetear su Clave';
$_['text_greeting'] = 'Una Nueva Clave fué requerida por la Administración de %s.';
$_['text_change']   = 'Para Resetear su Clave haga Click en el Enlace de abajo:';
$_['text_ip']       = 'La IP usada para hacer esta solicitud fué: %s';
?>