<?php
// Text
$_['text_subject']      = '%s - Orden Actualizada %s';
$_['text_order']        = 'ID Orden:';
$_['text_date_added']   = 'Fecha de la Orden:';
$_['text_order_status'] = 'Su Orden ha sido Actualizada al siguiente estado:';
$_['text_comment']      = 'Los comentarios para su Orden son:';
$_['text_link']         = 'Para ver su Orden haga Click en el Enlace de abajo:';
$_['text_footer']       = 'Por Favor responda este E-Mail sí tiene preguntas.';
?>