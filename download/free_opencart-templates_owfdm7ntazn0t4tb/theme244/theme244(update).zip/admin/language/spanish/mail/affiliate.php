<?php
// Text
$_['text_approve_subject']      = '%s - Su Cuenta de Afiliado ha sido Activada!';
$_['text_approve_welcome']      = 'Bienvenido y Gracias por Registrarse en %s!';
$_['text_approve_login']        = 'Su Cuenta ha sido Creada y puede Conectarse usando su Dirección E-Mail y Clave para visitar nuestro Sitio Web o en la siguiente Dirección Web:';
$_['text_approve_services']     = 'Una vez Conectado, Usted tiene la disponibilidad para Generar Códigos de Seguimiento, seguimiento de Pagos por Comisión y editar Información de su Cuenta';
$_['text_approve_thanks']       = 'Gracias,';
$_['text_transaction_subject']  = '%s - Comisión de Afiliado';
$_['text_transaction_received'] = 'Usted ha recibido Comisión de %s!';
$_['text_transaction_total']    = 'Su Monto Total de Comisión actual es de %s.';
?>