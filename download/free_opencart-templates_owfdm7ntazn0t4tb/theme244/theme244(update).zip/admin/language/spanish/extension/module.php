<?php
// Heading
$_['heading_title']    = 'Módulos';

// Text
$_['text_install']     = 'Instalar';
$_['text_uninstall']   = 'Desinstalar';

// Column
$_['column_name']      = 'Nombre de Módulo';
$_['column_action']    = 'Acción';

// Error
$_['error_permission'] = 'Advertencia: No tiene permiso para modificar módulos!';
?>