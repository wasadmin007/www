<?php
// Heading 
$_['heading_title']    = 'Gestor de Extensiones';

// Text
$_['text_success']     = 'Exito: Has instalado tu extension!';

// Error
$_['error_permission'] = 'Atenci�n: no tienes permiso para modificar el gestor de extensiones!';
$_['error_upload']     = 'Se requiere Upload!';
$_['error_filetype']   = 'Tipo de archivo invalido!';
?>