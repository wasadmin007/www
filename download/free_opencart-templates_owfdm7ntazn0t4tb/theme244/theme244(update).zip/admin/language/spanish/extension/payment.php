<?php
// Heading
$_['heading_title']     = 'Pagos';

// Text
$_['text_install']      = 'Instalar';
$_['text_uninstall']    = 'Desinstalar';

// Column
$_['column_name']       = 'Tipos de pagos';
$_['column_status']     = 'Estado';
$_['column_sort_order'] = 'Orden';
$_['column_action']     = 'Acción';

// Error
$_['error_permission']  = 'Advertencia: No tiene permiso para modificar tipos de pagos!';
?>