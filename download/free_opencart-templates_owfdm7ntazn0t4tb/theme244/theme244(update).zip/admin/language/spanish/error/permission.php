<?php
// Heading
$_['heading_title'] = 'Permiso Denegado!';

// Text
$_['text_permission'] = 'Usted no tiene permiso para accesar esta Página, por favor contacte a su Administrador Web.';
?>