<?php
// Heading
$_['heading_title'] = 'Página No Encontrada!';

// Text
$_['text_not_found'] = 'La página que está buscando no puede ser Encontrada! Por Favor contacte a su Administrador Web si el problema persiste.';
?>