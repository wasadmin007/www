<?php
// Heading
$_['heading_title']      = 'Module';

// Text
$_['text_install']       = 'Installieren';
$_['text_uninstall']     = 'Deinstallieren';

// Column
$_['column_name']        = 'Bezeichnung';
$_['column_action']      = 'Aktion';

// Error
$_['error_permission']   = 'Warnung: Sie haben keine Berechtigung, um Module zu ändern!';
?>
