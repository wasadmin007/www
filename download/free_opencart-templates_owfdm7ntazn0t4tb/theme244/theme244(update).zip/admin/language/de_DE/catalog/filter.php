<?php
$_['column_action']     = 'Aktion';
$_['column_group']      = 'Filtergruppe';
$_['column_sort_order'] = 'Reihenfolge';
$_['entry_group']       = 'Gruppenbezeichnung:';
$_['entry_name']        = 'Filterbezeichnung:';
$_['entry_sort_order']  = 'Reihenfolge:';
$_['error_group']       = 'Die Gruppenbezeichnung muss zwischen 3 und 64 Zeichen lang sein!';
$_['error_name']        = 'Die Filterbezeichnung muss zwischen 3 und 64 Zeichen lang sein!';
$_['error_permission']  = 'Warnung: Sie haben keine Berechtigung, um Filter zu ändern!';
$_['heading_title']     = 'Filter';
$_['text_success']      = 'Erfolgreich: Filter erfolgreich geändert!';
?>

