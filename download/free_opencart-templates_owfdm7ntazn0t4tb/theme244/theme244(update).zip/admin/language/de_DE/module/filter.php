<?php
$_['entry_layout']        = 'Layout:';
$_['entry_position']      = 'Position:';
$_['entry_sort_order']    = 'Reihenfolge:';
$_['entry_status']        = 'Status:';
$_['error_permission']    = 'Warnung: Sie haben keine Berechtigung, um Filter zu ändern!';
$_['heading_title']       = 'Filter';
$_['text_column_left']    = 'linke Spalte';
$_['text_column_right']   = 'rechte Spalte';
$_['text_content_bottom'] = 'Inhalt unten';
$_['text_content_top']    = 'Inhalt oben';
$_['text_module']         = 'Erweiterungen';
$_['text_success']        = 'Erfolgreich: Filter erfolgreich geändert.';
?>

