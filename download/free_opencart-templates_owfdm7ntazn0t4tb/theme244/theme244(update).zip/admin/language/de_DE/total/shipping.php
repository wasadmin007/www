<?php
// Heading
$_['heading_title']    = 'Versand';

// Text
$_['text_total']       = 'Auftragssummen';
$_['text_success']     = 'Erfolgreich: Versand erfolgreich geändert!';

// Entry
$_['entry_estimator']  = 'Frachtkalkulator:';
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Reihenfolge:';

// Error
$_['error_permission'] = 'Warnung: Sie haben keine Berechtigung, um Versand zu ändern!';
?>
