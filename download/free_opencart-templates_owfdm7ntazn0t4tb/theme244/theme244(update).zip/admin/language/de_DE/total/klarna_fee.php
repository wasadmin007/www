<?php
$_['text_denmark']        = 'Dänemark';
$_['text_finland']        = 'Finnland';
$_['text_germany']        = 'Deutschland';
$_['text_netherlands']    = 'Niederlande';
$_['text_norway']         = 'Norwegen';
$_['text_sweden']         = 'Schweden';
$_['entry_fee']           = 'Gebühr:';
$_['entry_sort_order']    = 'Reihenfolge:';
$_['entry_status']        = 'Status:';
$_['entry_tax_class']     = 'Steuerklasse:';
$_['entry_total']         = 'Summe:<br /><span class="help">Der Warenkorb muss diese Summe beinhalten, damit dieses Zahlungsverfahren verfügbar ist.</span>';
$_['error_permission']    = 'Warnung: Sie haben keine Berechtigung, um Klarna zu ändern!';
$_['heading_title']       = 'Klarna Gebühr';
$_['text_success']        = 'Erfolgreich: Klarna Gebühr erfolgreich geändert!';
$_['text_total']          = 'Auftragssummen';
?>

