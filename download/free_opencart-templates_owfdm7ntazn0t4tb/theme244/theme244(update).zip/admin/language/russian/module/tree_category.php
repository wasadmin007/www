<?php
// Heading
$_['heading_title']    = 'Дерево Категорий';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Ок: Настройки модуля сохранены!';
$_['text_left']        = 'Слева';
$_['text_right']       = 'Справа';

// Entry
$_['entry_position']   = 'Сторона:';
$_['entry_status']     = 'Статус:';
$_['entry_sort_order'] = 'Сортировка:';
$_['entry_counter']	   = 'Показывать количество товаров:';

// Error
$_['error_permission'] = 'Внимание: Вы не имеете прав менять настройки этого модуля!';
?>